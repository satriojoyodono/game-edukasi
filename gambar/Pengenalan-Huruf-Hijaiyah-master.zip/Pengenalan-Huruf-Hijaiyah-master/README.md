APLIKASI PENGENALAN HURUF HIJAIYAH

Media pengenalan huruf hijaiyah interaktif yang diperuntukkan bagi anak-anak dengan rentang usia 3-5 tahun.
Aplikasi ini dapat menampilkan cara pembacaan dari huruf hijaiyah dan harakatnya secara tertulis dan secara lisan.
Pengguna dalam aplikasi ini akan memilih salah satu dari huruf hijaiyah yang disediakan dalam aplikasi, kemudian pengguna memilih harakat yang ada, setelah selesai maka akan ditampilkan suara dari bacaan huruf tersebut dan keterangannya secara tertuis.
Aplikasi ini juga menyediakan quiz sebagai sarana evaluasi kemampuan pengguna terhadap pengenalan huruf hijaiyah.
Soal dalam quiz berupa keluaran suara yang kemudian pengguna menentukan tulisan dari suara yang dikeluarkan. Quiz dibagi menjadi 2 level, level 1 dan 2.


URL DOWNLOAD APLIKASI

Alamat URL 1 :
https://github.com/VivanEkoWicaksono/Pengenalan-Huruf-Hijaiyah/blob/master/bin/Pengenalan-Huruf-Hijaiyah.exe
Alamat URL 2 :
https://github.com/VivanEkoWicaksono/Pengenalan-Huruf-Hijaiyah/blob/master/bin/Pengenalan-Huruf-Hijaiyah.swf


PANDUAN INSTALASI

1. Download aplikasi pada alamat URL yang telah disediakan
2. Double klik program
3. Program dapat dijalankan
