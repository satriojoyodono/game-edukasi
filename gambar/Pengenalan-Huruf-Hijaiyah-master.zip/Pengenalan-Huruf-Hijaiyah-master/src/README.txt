Dependencies
   library lain yang perlu diinstall

Keterangan:
1. Folder desain
	- Memuat folder huruf dan folder template
	a. Folder huruf
		- memuat seluruh dokumen huruf dan harokat
		- ekstensi .png
	b. Folder Template
		- memuat rancangan desain yang digunakan dalam aplikasi
		
2. Folder suara
	- memuat seluruh suara yang di-import-kan ke dokumen .fla
	- file suara berekstensi .mp3

3. Link download.txt
	- Memuat link download yang memuat berkas .fla